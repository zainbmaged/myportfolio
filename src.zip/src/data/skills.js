
const skills = [
  {
    title: "Frontend",
    icon: "💻",
    technologies: [
      "React",
      "TypeScript",
      "Tailwind CSS",
      "HTML5",
    ],
  },
  {
    title: "Backend",
    icon: "⚙️",
    technologies: [
      "Django",
      "REST APIs",
      "PostgreSQL",
      "MongoDB",
    ],
  },
  {
    title:"Machine Learning & Deep Learning",
    icon: "🤖",
    technologies: [
      "Numpy and Pandas",
      "Torch",
      "TensorFlow",
      "Scikit-learn",
      "Matplotlib and Seaborn"
    ]
  },
  {title: "AI & Data Science", 
    icon: "🧠", 
    technologies: ["Natural Language Processing (NLP)",  "Reinforcement Learning", "Large Language Models (LLMs)", "Data Analysis and Visualization"]
  },{
        title: "Cloud & Deployment",
        icon: "☁️",
        technologies: [ "AWS", "Docker", "Kubernetes", "(CI/CD) Pipelines", "Cloud Deployment","IAC / Terraform"]
    },

    {title: "Version Control & Collaboration",
    icon: "🔧",
    technologies: ["Git", "GitHub","GitHub projects", "Agile Methodologies", "Team Collaboration"]
    },
    {title: "Additional Skills",
    icon: "🛠️",
    technologies: ["Problem Solving", "Critical Thinking", "Communication", "Leadership"]
    },
    {title: "Programming Languages",
    icon: "💻",
    technologies: ["Python", "JavaScript", "TypeScript", "SQL", "C++","Java"]
    }
];

export default skills;
