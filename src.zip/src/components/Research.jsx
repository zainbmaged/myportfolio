
import Card from "./ui/Card.jsx";
import Tag from "./ui/Tag.jsx";
import Section from "./ui/Section.jsx";
import SectionTitle from "./ui/SectionTitle.jsx";
import research from "../data/research.js";
import Button from "./ui/Button.jsx";

function Research (){

    return(

         <Section id="research" className="bg-[var(--background)] py-24">
            <SectionTitle
            title = "My Research"
            subtitle = "On Going research papers"
            />
       

<div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
        {research.map((category) => (
            <Card
                key={category.title}
                className="h-full"
            >
                <h3 className="flex items-center gap-2 text-xl font-bold text-[var(--text)]">
               
                    {category.title}
                </h3>

                <div className="flex flex-wrap gap-3 mt-6">
                    {category.topics.map((tech) => (
                        <Tag key={tech}>
                            {tech}
                        </Tag>
                    ))}
                </div>
            </Card>
        ))}
        </div>
         </Section>



    );
};

export default Research;