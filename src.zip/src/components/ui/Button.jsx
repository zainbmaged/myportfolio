
// props like variant is parameters passed to the component, and children is a special prop that represents the content between the opening and closing tags of the component. In this case, children will be the text or elements that are passed to the Button component when it is used in other parts of the application.
function Button({ children, href, variant = "primary" }) {

    const baseStyle =
        "px-6 py-3 rounded-lg font-medium transition-colors duration-300";

    const variants = {
        primary:
            "bg-[var(--primary)] text-white hover:bg-[var(--primary-hover)]",

        outline:
            "border-2 border-[var(--primary)] text-[var(--primary)] hover:bg-[var(--primary)] hover:text-white",
    };


    return(

        <a
        href = {href}
        className={`${baseStyle} ${variants[variant]}`}>
            {children}
        </a>
    );


}

export default Button;
