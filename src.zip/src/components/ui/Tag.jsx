
function Tag({children,varient="primary", className = ""}){

    return(
        <span className={`inline-flex
                items-center
                px-3
                py-1
                rounded-full
                bg-[var(--primary)]
                text-white
                text-sm
                font-medium
                transition-colors
                duration-300
                hover:bg-[var(--primary-hover)]
                ${className}`}>

            {children}
        </span>
    );
}export default Tag;