

function Card({ children,className = "" }) {


    return(
      
            <div
            className={`
                rounded-2xl
                bg-white
                shadow-md
                p-6
                transition-all
                duration-300
                hover:shadow-xl
                hover:-translate-y-1
                text-[var(--text)]
                ${className}
            `}
        >

            {children}

        </div>
     

    );

}export default Card;