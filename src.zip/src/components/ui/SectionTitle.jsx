
//conditional redering of subtitle using && operator inly if subtitle exists render this component otherwise do nothing
//grid vs flex - grid is used to create a two d layout for the story and highlights sections while flex is used to create a flexible in 1 d either column or row layout for the navbar and hero sections
function SectionTitle({ title, subtitle, align = "left"}){

    const alignment = {
    left: "text-left",
    center: "text-center",
    right: "text-right",
};

    return(
        <div
        className = {`mb-12 text-justify  ${alignment[align]}` }>
        <h2 className="text-4xl font-bold text-[var(--text)]">

                {title}

            </h2>

            {subtitle && (

                <p className="mt-3 text-justify text-[var(--text)]">

                    {subtitle}

                </p>

            )}


        </div>


    );
    
}
export default SectionTitle