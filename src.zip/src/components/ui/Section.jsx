

function Section({ id,className= "" , containerClassName = " ", children,}){

    return( 
        <section id={id} className={`py-24 ${className}`}>
            <div className={`max-w-7xl mx-auto px-8 ${containerClassName}`}>
                {children}
                </div>
                </section>
    );
}
export default Section;