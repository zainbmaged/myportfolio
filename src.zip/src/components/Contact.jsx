import Section from "./ui/Section";
import SectionTitle from "./ui/SectionTitle";
import Card from "./ui/Card";
import Button from "./ui/Button";

import {
  Mail,
  FileText,
  MapPin,
} from "lucide-react";
import { FaGithub ,FaLinkedin} from 'react-icons/fa'; 
import contact from "../data/contact";

function Contact() {

  const contacts = [
    {
      icon: <Mail size={22} />,
      title: "Email",
      value: contact.email,
      href: `mailto:${contact.email}`,
    },
    {
      icon: <FaGithub size={22} />,
      title: "GitHub",
      value: "github.com/zainbmaged",
      href: contact.github,
    },
    {
      icon: <FaLinkedin size={22} />,
      title: "LinkedIn",
      value: "Connect with me",
      href: contact.linkedin,
    },
    {
      icon: <FileText size={22} />,
      title: "Resume",
      value: "Download CV",
      href: contact.cv,
    },
    {
      icon: <MapPin size={22} />,
      title: "Location",
      value: contact.location,
    },
  ];

  return (
    <Section id="contact" className="bg-[var(--surface)]">

      <SectionTitle
        title="Let's Build Together"
        subtitle="Whether you're looking for an AI engineer, a full-stack developer, or a research collaborator, I'd love to hear about your project."
        align="center"
      />

      <Card>

        <div className="space-y-6">

          {contacts.map((item) => (

            item.href ? (
              <a
                key={item.title}
                href={item.href}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 hover:text-[var(--primary)] transition-colors duration-300"
              >
                {item.icon}

                <div>
                  <h3 className="font-semibold">
                    {item.title}
                  </h3>

                  <p className="text-[var(--text-secondary)]">
                    {item.value}
                  </p>
                </div>

              </a>
            ) : (
              <div
                key={item.title}
                className="flex items-center gap-4"
              >
                {item.icon}

                <div>
                  <h3 className="font-semibold">
                    {item.title}
                  </h3>

                  <p className="text-[var(--text-secondary)]">
                    {item.value}
                  </p>
                </div>
              </div>
            )

          ))}

        </div>

        <div className="mt-10 flex justify-center">
          <Button
            href={`mailto:${contact.email}`}
            variant="primary"
          >
            Send Me an Email
          </Button>
        </div>

      </Card>

    </Section>
  );
}

export default Contact;