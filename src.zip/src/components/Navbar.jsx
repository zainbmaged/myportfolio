
function Navbar() {
    return(
<nav className="shadow-md border-b sticky top-0 z-50 bg-[var(--white)]">

    <div className="max-w-7xl mx-auto flex justify-between items-center px-8 py-4">
       <a  href="#hero"
    className="text-2xl font-bold text-[var(--text)] hover:text-[var(--primary)] transition-colors duration-300" > Zainb  Zahran</a>
          <ul className="cursor-pointer flex  gap-8 text-[var(--text)] ">
                <li className="hover:text-[var(--primary)] transition-colors duration-300 "><a href="#about">About</a></li>
                <li className="hover:text-[var(--primary)] transition-colors duration-300"><a href="#skills">Skills</a></li>
                <li className="hover:text-[var(--primary)] transition-colors duration-300"><a href="#projects">Projects</a></li>
                <li className="hover:text-[var(--primary)] transition-colors duration-300"><a href="#research">Research</a></li>
                <li className="hover:text-[var(--primary)] transition-colors duration-300"><a href="#contact">Contact</a></li>

          </ul>
      </div>
     </nav>);
}
export default Navbar