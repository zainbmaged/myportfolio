 
import profile from "../assets/zainb.jpg";
import Button from "./ui/Button.jsx";
import Section from "./ui/Section.jsx";
function Hero() {
  return (
    <Section id="hero" className="bg-[var(--background)] py-24">


    <div className="max-w-7xl mx-auto px-8 flex flex-col md:flex-row items-center justify-between gap-12">
  {/* Left Side */}
  <div className="flex-1">
    <p className="text-lg text-[var(--primary)] font-semibold">
      Hi, I'm
    </p>

    <h1 className="text-5xl md:text-6xl font-extrabold text-[var(--text)] mt-2">
      Zainb Zahran
    </h1>

    <h2 className="text-2xl md:text-3xl font-semibold text-[var(--text)] mt-4">
      Full-Stack AI Engineer
    </h2>

    <p className="text-lg text-gray-600 mt-6 leading-8 max-w-xl">
      I help businesses transform ideas into production-ready AI applications
      by managing the entire development lifecycle—from intuitive frontend
      experiences and secure backend systems to AI integration, databases,
      APIs, and deployment.
    </p>

    <p className="text-gray-500 mt-4">
      I'm also a Teaching Assistant and currently pursuing my Master's in AI &
      Data Science at Queen's University.
    </p>

    <div className="flex gap-4 mt-8">
      <Button href="#projects" variant="primary">
      View Projects
      </Button>

      <Button href="#cv" variant="outline">
        Download CV
      </Button>
    </div>
  </div>

  {/* Right Side */}
  <div className="flex-1 flex justify-center">
    <div className="w-120 h-120 rounded-full bg-[var(--primary)] shadow-xl flex items-center justify-center">
      <img src={profile} alt="Zainb Zahran" className="w-110 h-100 rounded-full object-cover" />
    </div>
  </div>
  </div>
</Section>);
 }
 export default Hero;