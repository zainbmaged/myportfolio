
import Card from "./ui/Card.jsx";
import Tag from "./ui/Tag.jsx";
import Section from "./ui/Section.jsx";
import SectionTitle from "./ui/SectionTitle.jsx";
import skills from "../data/skills";

function Skills(){

    return(


<Section id="skills">
    <SectionTitle
        title="Skills"
        subtitle="My technical expertise and capabilities."
    />

    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8">
        {skills.map((category) => (
            <Card
                key={category.title}
                className="h-full"
            >
                <h3 className="flex items-center gap-2 text-xl font-bold text-[var(--text)]">
                    <span>{category.icon}</span>
                    {category.title}
                </h3>

                <div className="flex flex-wrap gap-3 mt-6">
                    {category.technologies.map((tech) => (
                        <Tag key={tech}>
                            {tech}
                        </Tag>
                    ))}
                </div>
            </Card>
        ))}
    </div>
</Section>

    );
}
export default Skills;