import Card from "./ui/Card.jsx";
import Tag from "./ui/Tag.jsx";
import Section from "./ui/Section.jsx";
import SectionTitle from "./ui/SectionTitle.jsx";
import projects from "../data/projects.js";
import Button from "./ui/Button.jsx";

function Projects(){

    return(
        <Section id="projects" className="bg-[var(--surface)] py-24">
            <SectionTitle
            title = "My Projects"
            subtitle = "A showcase of my work and contributions."
            />
           
<div className="flex flex-col gap-10">


            {projects.map((project) => (
                <Card key={project.title}>
                    <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 items-center justify-between p-8">

                    {/* Left Side */}
                    <div>
                        <h3 className="text-2xl font-bold text-[var(--text)]">
                        {project.title}
                        </h3>

                        <p className="mt-4 text-[var(--text-secondary)]">
                        {project.description}
                        </p>

                        <div className="flex flex-wrap gap-2 mt-6">
                        {project.technologies.map((tech) => (
                            <Tag key={tech}>{tech}</Tag>
                        ))}
                        </div>

                        <div className="flex gap-4 mt-6">
                        <Button href={project.github} variant="outline">
                            GitHub
                        </Button>

                        <Button href={project.demo} variant="primary">
                            Live Demo
                        </Button>
                        </div>
                    </div>

                    {/* Right Side */}
                    <div className="flex justify-center">
                    <a
                        href={project.demo}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="group block"
                    >
                        <img
                            src={project.image}
                            alt={project.title}
                            className="
                                rounded-2xl
                                shadow-lg
                                transition-transform
                                duration-300
                                group-hover:scale-105
                            "
                        />
                    </a>
                    </div>

                    </div>
                </Card>
                ))}
                    
</div>
             
        </Section>

    );
}
export default Projects;